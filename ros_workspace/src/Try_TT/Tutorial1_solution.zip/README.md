### Teleoperation

  sudo apt-get install ros-noetic-key-teleop

  rosrun key_teleop key_teleop.py

### Launch

  roslaunch object_server object_server.launch

  roslaunch rover_controller rover_controller.launch

  * Then set goal in RVIZ
  * Call /add_obstacles to add obstacle to the world 