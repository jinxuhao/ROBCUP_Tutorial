#include <math.h>

namespace rover_controller
{

  /**
   * @brief return the shortest angle from src to dst [-pi/2, pi/2]
   * 
   */
  inline float angle_error(double goal, double source ) 
  {
      return goal > source ? -M_PI + std::fmod(goal - source + M_PI, 2*M_PI)
                           :  M_PI - std::fmod(source - goal + M_PI, 2*M_PI);
  }
}