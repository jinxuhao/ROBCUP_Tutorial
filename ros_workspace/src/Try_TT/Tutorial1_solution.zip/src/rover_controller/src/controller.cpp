#include <rover_controller/controller.h>

#include <rover_controller/utilities.h>

namespace rover_controller
{

  Controller::Controller() : 
    has_goal_(false),
    map_frame_("map"),
    rover_frame_("rover"),
    rover_radius_(0.8)
  {
  }

  Controller::~Controller()
  {
  }

  bool Controller::initialize(ros::NodeHandle& nh)
  {
    // setup ros connections
    command_pub_ = nh.advertise<geometry_msgs::Twist>("/key_vel", 1);
    field_pub_ = nh.advertise<geometry_msgs::PoseArray>("/field", 1);

    goal_sub_ = nh.subscribe("/move_base_simple/goal", 1, &Controller::goalCallback, this);
    obstacles_sub_ = nh.subscribe("/obstacles", 1, &Controller::obstacleCallback, this);

    // get the parameters of this node (see config.yaml)
    std::vector<double> v;

    if(!ros::param::get("attractor_gain", v))
      return false;
    K_attractor_ = Eigen::Vector3d(v[0], v[1], v[2]).asDiagonal();

    if(!ros::param::get("repulsive_gain", v))
      return false;
    K_repulsive_ = Eigen::Vector3d(v[0], v[1], v[2]).asDiagonal();
    
    if(!ros::param::get("vortex_gain", v))
      return false;
    K_vortex_ = Eigen::Vector3d(v[0], v[1], v[2]).asDiagonal();

    // setup variables
    createVectorField(field_points_w_);

    prev_time_ = ros::Time::now();
    return true;
  }

  void Controller::update(const ros::Time& time, const ros::Duration durtation)
  {
    // get the rover pose in the map frame
    Eigen::Vector3d rover_pos_w = roverPos();

    // Rotation rover wrt world
    Eigen::Matrix3d R_b_w = Eigen::Matrix3d::Identity();
    R_b_w.topLeftCorner(2,2) = Eigen::Rotation2Dd(rover_pos_w.z()).matrix();

    // compute the thrust vector of the rover
    Eigen::Vector3d thrust_w = computeForce(
      obstacles_, goal_pos_w_, rover_pos_w);

    // transform into body frame for the rover
    Eigen::Vector3d thrust_b = R_b_w.transpose()*thrust_w;

    // send to the rover
    publishCommand(thrust_b);

    // visualize the field at low frequency
    if(time - prev_time_ > ros::Duration(1./5.))
    {
      prev_time_ = time;
      visualizerVectorField(obstacles_, goal_pos_w_, field_points_w_);
    }
  }

  Eigen::Vector3d Controller::computeForce(
    std::vector<Obstacle> obstacles, const Eigen::Vector3d& goal, 
    const Eigen::Vector3d& pos)
  {
    // compute the thrust vector wrt to world frame
    Eigen::Vector3d thrust_w = Eigen::Vector3d::Zero();  
    if(has_goal_)
    {
      thrust_w += goalAttractorForce(goal_pos_w_, pos);
    }

    // avoid collision
    thrust_w += obstacleRepulsiveForce(obstacles_, pos);

    // add vortex
    thrust_w += obstacleVortexForce(obstacles_, pos);
    
    return thrust_w;
  }

  Eigen::Vector3d Controller::roverPos()
  {
    // get the current rover pose in the map frame

    // see: http://wiki.ros.org/tf/Tutorials/Writing%20a%20tf%20listener%20%28C%2B%2B%29
    tf::StampedTransform transform;
    try {
      listener_.lookupTransform(map_frame_, rover_frame_, ros::Time(0), transform);
    }
    catch (tf::TransformException ex) 
    {
      transform.setIdentity();
    }

    Eigen::Vector3d pos;
    pos.x() = transform.getOrigin().x();
    pos.y() = transform.getOrigin().y();

    Eigen::Quaterniond Q(
      transform.getRotation().getW(),
      transform.getRotation().getX(),
      transform.getRotation().getY(),
      transform.getRotation().getZ());
    Eigen::Matrix2d M = Q.toRotationMatrix().topLeftCorner(2,2);
    pos.z() = Eigen::Rotation2Dd(M).angle();

    return pos;
  }

  Eigen::Vector3d Controller::goalAttractorForce(
    const Eigen::Vector3d& goal, const Eigen::Vector3d& pos)
  {
    Eigen::Vector3d err = goal - pos;
    err.z() = goal.z() - pos.z(); //angle_error(goal.z(), pos.z());

    if(err.norm() > 1.0)
    {
      err.normalize();
    }
    return K_attractor_*err;
  }

  Eigen::Vector3d Controller::obstacleRepulsiveForce(
    std::vector<Obstacle> obstacles, const Eigen::Vector3d& pos)
  {
    Eigen::Vector3d force = Eigen::Vector3d::Zero();

    Eigen::Vector3d v;
    double decay = 20;
    for(size_t i = 0; i < obstacles.size(); ++i)
    {
      v << (obstacles[i].pos - pos).head(2), 0;
      double d = v.norm();
      double a = obstacles[i].radius + rover_radius_;

      double f = std::exp(-decay*std::max(0.0, d - a));
      force -= K_repulsive_ * f * v.normalized();
    }
    return force;
  }

  Eigen::Vector3d Controller::obstacleVortexForce(
    std::vector<Obstacle> obstacles, const Eigen::Vector3d& pos)
  {
    Eigen::Vector3d force = Eigen::Vector3d::Zero();
    Eigen::Vector3d n_rover(std::sin(pos[2]), std::cos(pos[2]), 0.0);

    Eigen::Vector3d v;
    Eigen::Matrix3d R = Eigen::Matrix3d::Identity();

    double decay = 15;
    for(size_t i = 0; i < obstacles.size(); ++i)
    {
      v << (obstacles[i].pos - pos).head(2), 0;
      Eigen::Vector3d n_obs = v.normalized();

      double alpha = n_rover.dot(n_obs);
      if(alpha < 0)
      { 
        R.topLeftCorner(2,2) = Eigen::Rotation2Dd(-M_PI_2).matrix();
      }
      else
      {
        R.topLeftCorner(2,2) = Eigen::Rotation2Dd(+M_PI_2).matrix();
      }

      double d = v.norm();
      double a = obstacles[i].radius + rover_radius_;

      double f = std::exp(-decay*std::max(0.0, d - a));
      force -= K_vortex_ * f * R * v.normalized();
    }
    return force;
  }

  void Controller::publishCommand(const Eigen::Vector3d& thrust)
  {
    geometry_msgs::Twist msg;
    msg.linear.x = thrust.x();
    msg.linear.y = thrust.y();
    msg.linear.z = 0.0;
    msg.angular.x = 0.0;
    msg.angular.y = 0.0;
    msg.angular.z = thrust.z();
    command_pub_.publish(msg);
  }

  void Controller::createVectorField(std::vector<Eigen::Vector3d>& points)
  {
    // create a 10x10 mesh with evenly spaced points
    size_t n = 100;
    double len = 10.0;
    double dx = len / n;
    double dy = len / n;
    Eigen::Vector3d p;
    points.reserve(n*n);
    for(double x = -5.0; x < 5.0; x+=dx)
    {
      for(double y = -5.0; y < 5.0; y+=dx)
      {
        p << x, y, 0.0;
        points.push_back(p);
      }
    }
  }

  void Controller::visualizerVectorField(
    std::vector<Obstacle> obstacles, 
    const Eigen::Vector3d& goal,
    const std::vector<Eigen::Vector3d>& points)
  {
    geometry_msgs::PoseArray field_msg;
    field_msg.header.frame_id = map_frame_;
    field_msg.header.stamp = ros::Time::now();

    // evaluate the field at the points, obtain the directions
    field_msg.poses.resize(points.size());
    for(size_t i = 0; i < points.size(); ++i)
    {
      const Eigen::Vector3d& p = points[i];
      Eigen::Vector3d v = computeForce(obstacles, goal, p).normalized();
      Eigen::Quaterniond Q = Eigen::Quaterniond::FromTwoVectors(v, p);

      geometry_msgs::Pose& pose = field_msg.poses[i];
      pose.position.x = p.x();
      pose.position.y = p.y();
      pose.position.z = p.z();

      pose.orientation = tf::createQuaternionMsgFromYaw( std::atan2(v[1], v[0] ));
    }
    field_pub_.publish(field_msg);
  }

  //----------------------------------------------------------------------------
  // callbacks

  void Controller::goalCallback(const geometry_msgs::PoseStampedConstPtr& msg)
  {
    // note: goal_pos_w_ = [pos_x, pos_y, theta]

    has_goal_ = true;
    goal_pos_w_.x() = msg->pose.position.x;
    goal_pos_w_.y() = msg->pose.position.y;

    Eigen::Quaterniond Q_b_w(
      msg->pose.orientation.w,
      msg->pose.orientation.x,
      msg->pose.orientation.y,
      msg->pose.orientation.z);

    // theta \in [0, 2pi]
    Eigen::Matrix2d M = Q_b_w.toRotationMatrix().topLeftCorner(2,2);
    goal_pos_w_.z() = Eigen::Rotation2Dd(M).angle();

    // print the new goal
    ROS_WARN_STREAM("Controller::goalCallback: goal_pos_w=" << goal_pos_w_.transpose());
  }

  void Controller::obstacleCallback(const object_msgs::ObjectsConstPtr& msg)
  {
    // note obstacles_[i].pos = [pos_x, pos_y, pos_z]

    obstacles_.resize(msg->objects.size());
    for(size_t i = 0; i < msg->objects.size(); ++i)
    {
      obstacles_[i].pos << 
        msg->objects[i].pose.position.x,
        msg->objects[i].pose.position.y,
        msg->objects[i].pose.position.z;
      
      obstacles_[i].radius = msg->objects[i].radius.data;
    }
  }

}